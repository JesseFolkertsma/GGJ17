﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using CommonAssets.Pool;

[RequireComponent(typeof(Rigidbody))]
public class PopcornObject : BasePoolObject {

    public void pop (Transform pos)
    {
        this.transform.position = pos.position;

    }
}
